// import React from 'react';
// import { AppRegistry } from 'react-native';
// import { Provider } from 'react-redux';
// import configurationStore from './src/store/configurationStore';
import App from './App';
// import Home from './src/components/Home';

// const store = configurationStore();

// const RNRedux = () => (
//     <Provider store={store}>
//         <Home/>
//     </Provider>
// )

// AppRegistry.registerComponent('myFirstApp', () => RNRedux);
